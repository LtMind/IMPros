#include "execnormalprotocol.h"

#include <QDebug>
#include <QStringList>
#include "sqlanalysis.h"

#include "errorprotocol.h"

ExecNormalProtocol::ExecNormalProtocol(QObject *parent)
    :QObject(parent)
{
}

ExecNormalProtocol::~ExecNormalProtocol()
{

}

void ExecNormalProtocol::execOperateCmd(const NormalProtocol &protocol)
{
    m_protocol = protocol;
    qDebug() << "void ExecNormalProtocol::execUserOperate(void)";
    switch (m_protocol.m_operType) {
    case OperType_None: break;
    case OperType_Login: execOperateCmdLogin(); break;
    case OperType_User: execOperateCmdUser(); break;
    case OperType_Friend: execOperateCmdFriend(); break;
    case OperType_Crowd: execOperateCmdCrowd(); break;
    case OperType_Mood: execOperateCmdMood(); break;
    default: break;
    }
}

void ExecNormalProtocol::execOperateCmdLogin(void)
{
    qDebug() << "void ExecNormalProtocol::execOperateCmdLogin(void)";
    switch (m_protocol.m_operCmd) {
    case CmdLogin_LoginAsk: execOperateCmdLoginAsk(); break;
    case CmdLogin_ExitAsk: execOperateCmdExitAsk(); break;
    case CmdLogin_RegisterAsk: execOperateCmdRegisterAsk(); break;
    default: break;
    }
}

void ExecNormalProtocol::execOperateCmdUser(void)
{

}

void ExecNormalProtocol::execOperateCmdFriend(void)
{

}

void ExecNormalProtocol::execOperateCmdCrowd(void)
{

}

void ExecNormalProtocol::execOperateCmdChat(void)
{

}

void ExecNormalProtocol::execOperateCmdMood(void)
{

}

void ExecNormalProtocol::execOperateCmdLoginAsk(void)
{
    qDebug() << "void ExecNormalProtocol::execOperateCmdLoginAsk(void)";
    QStringList list = QString::fromLatin1(m_protocol.m_dataCont).split("|");

    UserInfo info = SQLAnalysis::selectUserInfo(list[0]);

    if(info.getPassword() == list[1])
    {
        QString msg = info.packageinfos();
        m_protocol.clearProtocolData();
        m_dataPacket.clearDataPacket();
        m_protocol.updateNormalProtocol(USER_NONE, USER_NONE,
                                        OperType_Login, CmdLogin_LoginAsk,
                                        DataType_Text, msg.toLatin1());

        m_dataPacket.updatePacketData(PacketType_Normal,&m_protocol);
        QByteArray buffer = m_dataPacket.packetData();
        emit signalSendDataToClient(buffer);
        emit signalUserLoginSuccess(info);
    }else
    {
        ErrorProtocol errorProtocol;
        m_dataPacket.clearDataPacket();
        errorProtocol.updateErrorProtocol(USER_NONE, USER_NONE,
                                        ErrorType_Data, ErrorData_LoginAsk);

        m_dataPacket.updatePacketData(PacketType_Error,&errorProtocol);
        QByteArray buffer = m_dataPacket.packetData();
        emit signalSendDataToClient(buffer);
    }
}

void ExecNormalProtocol::execOperateCmdExitAsk(void)
{

}

void ExecNormalProtocol::execOperateCmdRegisterAsk(void)
{

}
