#ifndef EXECERRORPROTOCOL_H
#define EXECERRORPROTOCOL_H

#include <QThread>

#include "common.h"
#include "errorprotocol.h"

class ExecErrorProtocol : public QObject
{
    Q_OBJECT
signals:
    void signalSendDataToClient(QByteArray buffer);

public:
    ExecErrorProtocol(QObject *parent = 0);
    ~ExecErrorProtocol();

    void execErrorType(void);
    void execErrorTypeNone(void);
    void execErrorNoneCorrectBack(void);
    void execErrorNoneHeartTest(void);
    void execErrorNoneHeartBack(void);

    void execErrorTypeData(void);
    void execErrorDataLoginAsk(void);

    void execErrorTypeAuth(void);
    void execErrorTypeServ(void);

protected:
    void run();

private:
    ErrorProtocol m_errorProtocol;
};

#endif // EXECERRORPROTOCOL_H
