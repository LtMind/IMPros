#ifndef EXECNORMALPROTOCOL_H
#define EXECNORMALPROTOCOL_H

#include <QThread>

#include "common.h"
#include "datapacket.h"
#include "normalprotocol.h"

class ExecNormalProtocol: public QObject
{
    Q_OBJECT

signals:
    void signalSendDataToClient(QByteArray buffer);
    void signalUserLoginSuccess(UserInfo info);

public:
    ExecNormalProtocol(QObject *parent = 0);
    ~ExecNormalProtocol();

    void execOperateCmd(const NormalProtocol &protocol);

    void execOperateCmdLogin(void);
    void execOperateCmdLoginAsk(void);
    void execOperateCmdExitAsk(void);
    void execOperateCmdRegisterAsk(void);

    void execOperateCmdUser(void);
    void execOperateCmdFriend(void);
    void execOperateCmdCrowd(void);
    void execOperateCmdChat(void);
    void execOperateCmdMood(void);

private:
    NormalProtocol m_protocol;
    DataPacket m_dataPacket;
};

#endif // EXECNORMALPROTOCOL_H
