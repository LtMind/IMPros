#include "execerrorprotocol.h"

#include <QDebug>

ExecErrorProtocol::ExecErrorProtocol(QObject *parent)
    :QObject(parent)
{
}

ExecErrorProtocol::~ExecErrorProtocol()
{

}

void ExecErrorProtocol::execErrorType(void)
{
    qDebug() << "void ExecErrorProtocol::execErrorType(void)";
    switch (m_errorProtocol.m_errorType) {
    case ErrorType_None: execErrorTypeNone(); break;
    case ErrorType_Data: execErrorTypeData(); break;
    case ErrorType_Auth: execErrorTypeAuth(); break;
    case ErrorType_Serv: execErrorTypeServ(); break;
    default: break;
    }
}

void ExecErrorProtocol::execErrorTypeNone(void)
{
    qDebug() << "1111111111111111111";
    switch (m_errorProtocol.m_errorType) {
    case ErrorNone_CorrectBack: execErrorNoneCorrectBack(); break;
    case ErrorNone_HeartTest: execErrorNoneHeartTest(); break;
    case ErrorNone_HeartBack: execErrorNoneHeartBack(); break;
    default: break;
    }
}

void ExecErrorProtocol::execErrorTypeData(void)
{
    qDebug() << "2222222222222222222222222";
    switch (m_errorProtocol.m_errorType) {
    case ErrorData_LoginAsk: execErrorDataLoginAsk(); break;
    default: break;
    }
}

void ExecErrorProtocol::execErrorDataLoginAsk(void)
{
    qDebug() << "33333333333333333333333333";
}

void ExecErrorProtocol::execErrorTypeAuth(void)
{

}

void ExecErrorProtocol::execErrorTypeServ(void)
{

}

void ExecErrorProtocol::execErrorNoneCorrectBack(void)
{

}

void ExecErrorProtocol::execErrorNoneHeartTest(void)
{

}

void ExecErrorProtocol::execErrorNoneHeartBack(void)
{

}

