#ifndef SQLANALYSIS_H
#define SQLANALYSIS_H

#include <QString>

#include "common.h"

class SQLAnalysis
{
public:
    SQLAnalysis();

    static PersonInfo *selectPersonInfo(QString id);
    static RegisterInfo *selectRegisterInfo(QString id);
    static UserInfo selectUserInfo(QString id);
};

#endif // SQLANALYSIS_H
