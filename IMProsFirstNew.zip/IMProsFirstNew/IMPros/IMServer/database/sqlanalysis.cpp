#include "sqlanalysis.h"

#include <QSqlQuery>
#include <QSqlRecord>
#include <QStringList>

#include <QDebug>

SQLAnalysis::SQLAnalysis()
{

}

PersonInfo *SQLAnalysis::selectPersonInfo(QString id)
{
    PersonInfo *info = new PersonInfo;
    QSqlQuery query;
    QString basicString = QString("select * from PersonInfoTable "
                                  "where PersonInfoTable.ID = '%1'");
    QString queryString = basicString.arg(id);

    if(query.exec(queryString))
    {
        int id_idx = query.record().indexOf("PID");
        int name_idx = query.record().indexOf("PName");
        int sex_idx = query.record().indexOf("PSex");
        int birth_idx = query.record().indexOf("PBirth");

        while (query.next())
        {
            QString id = query.value(id_idx).toString();
            QString name = query.value(name_idx).toString();
            QString sex = query.value(sex_idx).toString();
            QString birth = query.value(birth_idx).toString();

            info->updataPersoninfo(id, name, sex, birth);
        }
    }

    return info;
}

RegisterInfo *SQLAnalysis::selectRegisterInfo(QString id)
{
    RegisterInfo *info = new RegisterInfo;
    QSqlQuery query;
    QString basicString = QString("select * from RegisterInfoTable "
                                  "where RegisterInfoTable.RID = '%1'");
    QString queryString = basicString.arg(id);

    if(query.exec(queryString))
    {
        int id_idx = query.record().indexOf("RID");
        int name_idx = query.record().indexOf("RName");
        int pswd_idx = query.record().indexOf("RPassword");
        int time_idx = query.record().indexOf("RTime");

        while (query.next())
        {
            QString id = query.value(id_idx).toString();
            QString name = query.value(name_idx).toString();
            QString pswd = query.value(pswd_idx).toString();
            QString time = query.value(time_idx).toString();

            info->updataRegisterinfo(id, name, pswd, time);
        }
    }

    return info;
}

UserInfo SQLAnalysis::selectUserInfo(QString id)
{
    UserInfo info;
    QSqlQuery query;
    QString basicString = QString("select * from UserInfoTable "
                                  "where UserInfoTable.UID = '%1'");
    QString queryString = basicString.arg(id);

    if(query.exec(queryString))
    {
        int uid_idx = query.record().indexOf("UID");
        int rid_idx = query.record().indexOf("RID");
        int selfsign_idx = query.record().indexOf("SelfSign");
        int ipid_idx = query.record().indexOf("IpID");

        while (query.next())
        {
            QString uid = query.value(uid_idx).toString();
            QString rid = query.value(rid_idx).toString();
            QString selfsign = query.value(selfsign_idx).toString();
            QString ipid = query.value(ipid_idx).toString();

            info.updataUserinfo(uid, rid, selfsign, ipid);
            info.updataRegisterinfo(selectRegisterInfo(rid));
        }
    }

    return info;
}

