#ifndef LOGICLAYER_H
#define LOGICLAYER_H

#include <QObject>
#include "common.h"

class Login;
class MainWindow;
class ListenClient;

class LogicLayer : public QObject
{
    Q_OBJECT

public slots:
    void slotUserLoginSuccess(UserInfo info);

public:
    explicit LogicLayer(QObject *parent = 0);
    ~LogicLayer();

    void showLoginW(void);

private:
    Login *m_login;
    MainWindow *m_mainw;
    ListenClient *m_tcpServer;
};

#endif // LOGICLAYER_H
