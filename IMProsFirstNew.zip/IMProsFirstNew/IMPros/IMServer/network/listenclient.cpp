#include "listenclient.h"

#include <QTcpSocket>
#include <QTime>
#include <QDebug>

ListConnectClient ListenClient::g_listConnectClient;

ListenClient::ListenClient()
{
    m_imServer = new QTcpServer(this);
    m_imServer->listen(QHostAddress::Any, 55555);

    connect(m_imServer, SIGNAL(newConnection()),
            this, SLOT(slotServerConnected()));
}

ListenClient::~ListenClient()
{
}

void ListenClient::slotServerConnected()
{
    ConnectClient *socket = new ConnectClient(
                m_imServer->nextPendingConnection());

    connect(socket, SIGNAL(signalUserLoginSuccess(UserInfo)),
            this, SIGNAL(signalUserLoginSuccess(UserInfo)));
    g_listConnectClient.append(socket);

    socket->start();
}
