#include "connectclient.h"

QueueNormalProtocol ConnectClient::g_queueNormalProtocol;
QueueErrorProtocol ConnectClient::g_queueErrorProtocol;
QueueChatProtocol ConnectClient::g_queueChatProtocol;
QueueGroupChatProtocol ConnectClient::g_queueGroupChatProtocol;

ConnectClient::ConnectClient(QTcpSocket *nect, QObject *parent)
    :QThread(parent)
{
    m_isExitThread = false;
    m_execNormalProtocol = new ExecNormalProtocol(parent);
    m_execErrorProtocol = new ExecErrorProtocol();
    m_socket = nect;
    connect(m_socket, SIGNAL(readyRead()),
            this, SLOT(slotReadyRead()));
    connect(m_execNormalProtocol, SIGNAL(signalSendDataToClient(QByteArray)),
            this, SLOT(slotSendDataToClient(QByteArray)));
    connect(m_execNormalProtocol, SIGNAL(signalUserLoginSuccess(UserInfo)),
            this, SIGNAL(signalUserLoginSuccess(UserInfo)));
}

ConnectClient::~ConnectClient()
{
    delete m_execNormalProtocol;
    delete m_socket;
}

void ConnectClient::slotReadyRead()
{
    qDebug() << "ConnectClient::slotReadyRead()";
    m_recvDataPacket.clearDataPacket();
    m_recvDataPacket.unpacketData(m_socket);
}

void ConnectClient::slotSendDataToClient(QByteArray buffer)
{
    qDebug() << "void ConnectClient::slotSendDataToClient(QByteArray *buffer)";
    qDebug() << "Send: " << buffer.toHex();
    m_socket->write(buffer);
}

void ConnectClient::run()
{
    while(!m_isExitThread)
    {
        if(!g_queueNormalProtocol.isEmpty())
        {
            m_normalProtocol.clearProtocolData();
            m_normalProtocol = g_queueNormalProtocol.dequeue();
            m_normalProtocol.displayProtocol();
            m_execNormalProtocol->execOperateCmd(m_normalProtocol);
        }

        if(!g_queueErrorProtocol.isEmpty())
        {
            m_normalProtocol.clearProtocolData();
            m_normalProtocol = g_queueNormalProtocol.dequeue();
            m_normalProtocol.displayProtocol();
            m_execNormalProtocol->execOperateCmd(m_normalProtocol);
        }

        msleep(20);
    }
}

