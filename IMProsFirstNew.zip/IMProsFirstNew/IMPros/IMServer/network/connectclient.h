#ifndef CONNECT_CLIENT_H
#define CONNECT_CLIENT_H

#include <QString>
#include <QList>
#include <QTcpSocket>
#include <QObject>

#include "datapacket.h"
#include "normalprotocol.h"
#include "errorprotocol.h"
#include "chatprotocol.h"

#include "execnormalprotocol.h"
#include "execerrorprotocol.h"

#include <QList>

class ConnectClient: public QThread
{
    Q_OBJECT

signals:
    void signalUserLoginSuccess(UserInfo info);

public slots:
    void slotReadyRead();
    void slotSendDataToClient(QByteArray buffer);

public:
    ConnectClient(QTcpSocket *nect, QObject *parent = 0);
    ~ConnectClient();

    static QueueNormalProtocol g_queueNormalProtocol;
    static QueueErrorProtocol g_queueErrorProtocol;
    static QueueChatProtocol g_queueChatProtocol;
    static QueueGroupChatProtocol g_queueGroupChatProtocol;

protected:
    void run();

private:
    QTcpSocket *m_socket;

    bool m_isExitThread;
    DataPacket m_recvDataPacket;

    NormalProtocol m_normalProtocol;
    ExecNormalProtocol *m_execNormalProtocol;

    ErrorProtocol m_errorProtocol;
    ExecErrorProtocol *m_execErrorProtocol;
};

typedef QList<ConnectClient *> ListConnectClient;

#endif // CONNECT_CLIENT_H
