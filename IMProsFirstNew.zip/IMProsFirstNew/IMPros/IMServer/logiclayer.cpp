#include "logiclayer.h"

#include "login.h"
#include "mainwindow.h"
#include "userinfo.h"
#include "listenclient.h"

LogicLayer::LogicLayer(QObject *parent) :
    QObject(parent)
{
    m_tcpServer = new ListenClient();
    m_mainw = new MainWindow();

    m_login = new Login();

    connect(m_login, SIGNAL(signalLoginSuccess(UserInfo)),
            m_mainw, SLOT(slotLoginSuccess(UserInfo)));

    connect(m_tcpServer, SIGNAL(signalUserLoginSuccess(UserInfo)),
            this, SLOT(slotUserLoginSuccess(UserInfo)));
}

LogicLayer::~LogicLayer()
{
    delete m_tcpServer;
    delete m_login;
    delete m_mainw;
}

void LogicLayer::slotUserLoginSuccess(UserInfo info)
{
    m_mainw->addOnlineUser(info);
}

void LogicLayer::showLoginW(void)
{
    m_login->show();
}

