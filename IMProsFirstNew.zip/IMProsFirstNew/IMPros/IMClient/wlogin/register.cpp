#include "register.h"
#include "ui_register.h"

Register::Register(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Register)
{
    ui->setupUi(this);
}

Register::~Register()
{
    delete ui;
}

void Register::closeEvent(QCloseEvent *ev)
{
    emit signalCloseProject();
    ev->accept();
}
