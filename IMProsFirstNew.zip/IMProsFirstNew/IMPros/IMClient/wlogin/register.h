#ifndef REGISTER_H
#define REGISTER_H

#include <QWidget>
#include <QCloseEvent>

namespace Ui {
class Register;
}

class Register : public QWidget
{
    Q_OBJECT

signals:
    void signalCloseProject(void);

public:
    explicit Register(QWidget *parent = 0);
    ~Register();

protected:
    void closeEvent(QCloseEvent *ev);

private:
    Ui::Register *ui;
};

#endif // REGISTER_H
