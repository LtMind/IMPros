#ifndef IMGLOBAL_H
#define IMGLOBAL_H

#include <QMap>

#include "datapacket.h"
#include "normalprotocol.h"
#include "errorprotocol.h"
#include "chatprotocol.h"

class IMGlobal
{
public:
    IMGlobal();
    ~IMGlobal();
};

#endif // IMGLOBAL_H
