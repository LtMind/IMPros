#include "connectclient.h"

ConnectClient::ConnectClient(QTcpSocket *nect)
{
    m_execNormalProtocol = new ExecNormalProtocol;
    m_socket = nect;
    connect(m_socket, SIGNAL(readyRead()),
            this, SLOT(slotReadyRead()));
    connect(m_execNormalProtocol, SIGNAL(signalSendDataToClient(QByteArray)),
            this, SLOT(slotSendDataToClient(QByteArray)));
    connect(m_execNormalProtocol, SIGNAL(signalUserLoginSuccess(UserInfo)),
            this, SIGNAL(signalUserLoginSuccess(UserInfo)));

    m_execNormalProtocol->start();
}

ConnectClient::~ConnectClient()
{
    if(m_execNormalProtocol->isRunning())
    {
        m_execNormalProtocol->quit();
    }
    delete m_execNormalProtocol;
    delete m_socket;
}

void ConnectClient::slotReadyRead()
{
    qDebug() << "ConnectClient::slotReadyRead()";
    m_recvDataPacket.clearDataPacket();
    m_recvDataPacket.unpacketData(m_socket);
}

void ConnectClient::slotSendDataToClient(QByteArray buffer)
{
    qDebug() << "void ConnectClient::slotSendDataToClient(QByteArray *buffer)";
    qDebug() << "Send: " << buffer.toHex();
    m_socket->write(buffer);
}

