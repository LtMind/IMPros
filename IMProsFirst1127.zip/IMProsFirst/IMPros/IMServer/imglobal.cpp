#include "imglobal.h"

quint32 IMGlobal::g_msgID;
MapUserAndSocket IMGlobal::g_mapUserAndSocket;

IMGlobal::IMGlobal()
{

}

IMGlobal::~IMGlobal()
{

}
