#include "connectsql.h"
#include <QDebug>
#include <QSqlError>

DataBase::DataBase()
{
    QSqlDatabase db;
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("../database/IMDataBase.db");

    if(!db.open())
    {
        qCritical("Can't open database: %s(%s)",
                  db.lastError().text().toLocal8Bit().data(),
                  qt_error_string().toLocal8Bit().data());
    }
}

DataBase::~DataBase()
{
    QSqlDatabase::database().close();
}



