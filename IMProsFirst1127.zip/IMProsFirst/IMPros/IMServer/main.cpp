#include <QApplication>

#include "connectsql.h"
#include "logiclayer.h"
#include <QMetaType>

int main(int argc, char *argv[])
{
    qRegisterMetaType<UserInfo>("UserInfo");
    QApplication app(argc, argv);

    DataBase db;

    LogicLayer logic;
    logic.showLoginW();

    return app.exec();
}
