#include "execnormalprotocol.h"

#include <QDebug>
#include <QStringList>
#include "sqlanalysis.h"
#include "protocol.h"

#include "errorprotocol.h"

ExecNormalProtocol::ExecNormalProtocol()
{
    Protocol::g_queueNormalProtocol.clear();
}

ExecNormalProtocol::~ExecNormalProtocol()
{

}

void ExecNormalProtocol::run()
{
    while(true)
    {
        if(!Protocol::g_queueNormalProtocol.isEmpty())
        {
            m_normalProtocol.clearProtocolData();
            m_normalProtocol = Protocol::g_queueNormalProtocol.dequeue();
            m_normalProtocol.displayProtocol();
            execUserOperate();
        }

        msleep(20);
    }
}

void ExecNormalProtocol::execUserOperate(void)
{
    qDebug() << "void ExecNormalProtocol::execUserOperate(void)";
    switch (m_normalProtocol.m_operType) {
    case OperType_None: break;
    case OperType_Login: execOperateCmdLogin(); break;
    case OperType_User: execOperateCmdUser(); break;
    case OperType_Friend: execOperateCmdFriend(); break;
    case OperType_Crowd: execOperateCmdCrowd(); break;
    case OperType_Mood: execOperateCmdMood(); break;
    default: break;
    }
}

void ExecNormalProtocol::execOperateCmdLogin(void)
{
    qDebug() << "void ExecNormalProtocol::execOperateCmdLogin(void)";
    switch (m_normalProtocol.m_operCmd) {
    case CmdLogin_LoginAsk: execOperateCmdLoginAsk(); break;
    case CmdLogin_ExitAsk: execOperateCmdExitAsk(); break;
    case CmdLogin_RegisterAsk: execOperateCmdRegisterAsk(); break;
    default: break;
    }
}

void ExecNormalProtocol::execOperateCmdUser(void)
{

}

void ExecNormalProtocol::execOperateCmdFriend(void)
{

}

void ExecNormalProtocol::execOperateCmdCrowd(void)
{

}

void ExecNormalProtocol::execOperateCmdChat(void)
{

}

void ExecNormalProtocol::execOperateCmdMood(void)
{

}

void ExecNormalProtocol::execOperateCmdLoginAsk(void)
{
    qDebug() << "void ExecNormalProtocol::execOperateCmdLoginAsk(void)";
    QStringList list = QString::fromLatin1(m_normalProtocol.m_dataCont).split("|");

    UserInfo info = SQLAnalysis::selectUserInfo(list[0]);

    if(info.getPassword() == list[1])
    {
        QString msg = info.packageinfos();
        m_normalProtocol.clearProtocolData();
        m_dataPacket.clearDataPacket();
        m_normalProtocol.updateNormalProtocol(USER_NONE, USER_NONE,
                                        OperType_Login, CmdLogin_LoginAsk,
                                        DataType_Text, msg.toLatin1());

        m_dataPacket.updatePacketData(PacketType_Normal,&m_normalProtocol);
        QByteArray buffer = m_dataPacket.packetData();
        emit signalSendDataToClient(buffer);
        emit signalUserLoginSuccess(info);
    }else
    {
        ErrorProtocol errorProtocol;
        m_dataPacket.clearDataPacket();
        errorProtocol.updateErrorProtocol(USER_NONE, USER_NONE,
                                        ErrorType_Data, ErrorData_LoginAsk);

        m_dataPacket.updatePacketData(PacketType_Error,&errorProtocol);
        QByteArray buffer = m_dataPacket.packetData();
        emit signalSendDataToClient(buffer);
    }
}

void ExecNormalProtocol::execOperateCmdExitAsk(void)
{

}

void ExecNormalProtocol::execOperateCmdRegisterAsk(void)
{

}
