#ifndef IMGLOBAL_H
#define IMGLOBAL_H

#include <QMap>

class IMGlobal
{
public:
    IMGlobal();
    ~IMGlobal();
};

#endif // IMGLOBAL_H
