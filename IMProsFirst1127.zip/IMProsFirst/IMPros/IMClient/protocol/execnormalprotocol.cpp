#include "execnormalprotocol.h"

#include <QDebug>
#include <QStringList>

#include "common.h"
#include "protocol.h"

ExecNormalProtocol::ExecNormalProtocol(QObject *parent)
    :QThread(parent)
{
    Protocol::g_queueNormalProtocol.clear();
}

ExecNormalProtocol::~ExecNormalProtocol()
{

}

void ExecNormalProtocol::run()
{
    while(true)
    {
        if(!Protocol::g_queueNormalProtocol.isEmpty())
        {
            m_normalProtocol.clearProtocolData();
            m_normalProtocol = Protocol::g_queueNormalProtocol.dequeue();
            m_normalProtocol.displayProtocol();
            execUserOperate();
        }

        msleep(20);
    }
}

void ExecNormalProtocol::execUserOperate(void)
{
    qDebug() << "void ExecNormalProtocol::execUserOperate(void)";
    switch (m_normalProtocol.m_operType) {
    case OperType_None: break;
    case OperType_Login: execOperateCmdLogin(); break;
    case OperType_User: execOperateCmdUser(); break;
    case OperType_Friend: execOperateCmdFriend(); break;
    case OperType_Crowd: execOperateCmdCrowd(); break;
    case OperType_Mood: execOperateCmdMood(); break;
    default: break;
    }
}

void ExecNormalProtocol::execOperateCmdLogin(void)
{
    qDebug() << "void ExecNormalProtocol::execOperateCmdLogin(void)";
    switch (m_normalProtocol.m_operCmd) {
    case CmdLogin_LoginAsk: execOperateCmdLoginAsk(); break;
    case CmdLogin_ExitAsk: execOperateCmdExitAsk(); break;
    case CmdLogin_RegisterAsk: execOperateCmdRegisterAsk(); break;
    default: break;
    }
}

void ExecNormalProtocol::execOperateCmdUser(void)
{

}

void ExecNormalProtocol::execOperateCmdFriend(void)
{

}

void ExecNormalProtocol::execOperateCmdCrowd(void)
{

}

void ExecNormalProtocol::execOperateCmdChat(void)
{

}

void ExecNormalProtocol::execOperateCmdMood(void)
{

}

void ExecNormalProtocol::execOperateCmdLoginAsk(void)
{
    QStringList list = QString::fromLatin1(m_normalProtocol.m_dataCont).split("|");
    qDebug() << list;

    UserInfo *info = new UserInfo;
    info->updataRegisterinfo(list[0], list[1], list[2], list[3]);
    info->updataIpAddrInfo(list[4], list[5], list[6]);
    info->updataUserinfo(list[7], list[8], list[9], list[10]);
    emit signalUserLoginSuccess(info);
}

void ExecNormalProtocol::execOperateCmdExitAsk(void)
{

}

void ExecNormalProtocol::execOperateCmdRegisterAsk(void)
{

}
