#ifndef EXECNORMALPROTOCOL_H
#define EXECNORMALPROTOCOL_H

#include <QThread>

#include "common.h"
#include "normalprotocol.h"

class ExecNormalProtocol: public QThread
{
    Q_OBJECT
signals:
    void signalUserLoginSuccess(UserInfo *info);

public:
    ExecNormalProtocol(QObject *parent = 0);
    ~ExecNormalProtocol();

    void execUserOperate(void);

    void execOperateCmdLogin(void);
    void execOperateCmdUser(void);
    void execOperateCmdFriend(void);
    void execOperateCmdCrowd(void);
    void execOperateCmdChat(void);
    void execOperateCmdMood(void);

    void execOperateCmdLoginAsk(void);
    void execOperateCmdExitAsk(void);
    void execOperateCmdRegisterAsk(void);

protected:
    void run();

private:
    NormalProtocol m_normalProtocol;
};

#endif // EXECNORMALPROTOCOL_H
