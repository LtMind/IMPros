#include "execerrorprotocol.h"

#include <QDebug>
#include "protocol.h"

ExecErrorProtocol::ExecErrorProtocol(QObject *parent)
    :QThread(parent)
{

}

ExecErrorProtocol::~ExecErrorProtocol()
{

}

void ExecErrorProtocol::run()
{
    while(true)
    {
        if(!Protocol::g_queueErrorProtocol.isEmpty())
        {
            m_errorProtocol.clearProtocolData();
            m_errorProtocol = Protocol::g_queueErrorProtocol.dequeue();
            m_errorProtocol.displayProtocol();
            execErrorType();
        }

        msleep(20);
    }
}

void ExecErrorProtocol::execErrorType(void)
{
    qDebug() << "void ExecErrorProtocol::execErrorType(void)";
    switch (m_errorProtocol.m_errorType) {
    case ErrorType_None: execErrorTypeNone(); break;
    case ErrorType_Data: execErrorTypeData(); break;
    case ErrorType_Auth: execErrorTypeAuth(); break;
    case ErrorType_Serv: execErrorTypeServ(); break;
    default: break;
    }
}

void ExecErrorProtocol::execErrorTypeNone(void)
{
    qDebug() << "void ExecErrorProtocol::execErrorType(void)";
    switch (m_errorProtocol.m_errorType) {
    case ErrorNone_CorrectBack: execErrorNoneCorrectBack(); break;
    case ErrorNone_HeartTest: execErrorNoneHeartTest(); break;
    case ErrorNone_HeartBack: execErrorNoneHeartBack(); break;
    default: break;
    }
}

void ExecErrorProtocol::execErrorTypeData(void)
{

}

void ExecErrorProtocol::execErrorTypeAuth(void)
{

}

void ExecErrorProtocol::execErrorTypeServ(void)
{

}

void ExecErrorProtocol::execErrorNoneCorrectBack(void)
{

}

void ExecErrorProtocol::execErrorNoneHeartTest(void)
{

}

void ExecErrorProtocol::execErrorNoneHeartBack(void)
{

}

