#include "connectserver.h"

#include <QTcpSocket>
#include <QDebug>

#include "logiclayer.h"

ConnectServer::ConnectServer(QObject *parent) :
    QObject(parent)
{
    m_exeErrorProtocol = new ExecErrorProtocol(parent);
    m_execNormalProtocol = new ExecNormalProtocol(parent);
    m_socket = new QTcpSocket(this);

    connect(m_socket, SIGNAL(readyRead()),
            this, SLOT(slotReadyRead()));

    connect(m_execNormalProtocol, SIGNAL(signalUserLoginSuccess(UserInfo*)),
            this, SIGNAL(signalUserLoginSuccess(UserInfo*)));

    m_socket->connectToHost("localhost", 55555);
    m_exeErrorProtocol->start();
    m_execNormalProtocol->start();
}

ConnectServer::~ConnectServer()
{
    qDebug() << "ConnectServer::~ConnectServer()";
    if(m_execNormalProtocol->isRunning())
    {
        m_execNormalProtocol->quit();
    }
    delete m_execNormalProtocol;
    delete m_socket;
}

void ConnectServer::closeThreads(void)
{
    if(m_exeErrorProtocol->isRunning())
    {
        m_exeErrorProtocol->quit();
    }
    if(m_execNormalProtocol->isRunning())
    {
        m_execNormalProtocol->quit();
    }
    delete m_execNormalProtocol;
    delete m_socket;
}

void ConnectServer::slotConnectServer(QString id, QString pswd)
{
    QString msg = id + "|" + pswd;
    m_sendDataPacket.clearDataPacket();
    NormalProtocol normalProtocol(USER_NONE, USER_NONE,
                                  OperType_Login, CmdLogin_LoginAsk,
                                  DataType_Text, msg.toLatin1());
    m_sendDataPacket.updatePacketData(PacketType_Normal,&normalProtocol);
    QByteArray buffer = m_sendDataPacket.packetData();
    qDebug() << "Send: " << buffer.toHex();
    m_socket->write(buffer);
}

void ConnectServer::slotReadyRead()
{
    qDebug() << "ConnectServer::slotReadyRead";
    m_recvDataPacket.clearDataPacket();
    m_recvDataPacket.unpacketData(m_socket);
}

