#ifndef CONNECTSERVER_H
#define CONNECTSERVER_H

#include <QObject>

#include "datapacket.h"
#include "execnormalprotocol.h"
#include "execerrorprotocol.h"

class QTcpSocket;

class ConnectServer : public QObject
{
    Q_OBJECT

signals:
    void signalUserLoginSuccess(UserInfo *info);

public slots:
    void slotReadyRead();
    void slotConnectServer(QString id, QString pswd);

public:
    explicit ConnectServer(QObject *parent = 0);
    ~ConnectServer();

    void closeThreads(void);

private:
    QTcpSocket *m_socket;

    DataPacket m_recvDataPacket;
    DataPacket m_sendDataPacket;

    ExecErrorProtocol *m_exeErrorProtocol;
    ExecNormalProtocol *m_execNormalProtocol;
};

#endif // CONNECTSERVER_H
