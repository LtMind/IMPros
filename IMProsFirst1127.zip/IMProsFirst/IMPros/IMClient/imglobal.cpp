#include "imglobal.h"

IMGlobal::IMGlobal(){

}

IMGlobal::~IMGlobal(){

}

