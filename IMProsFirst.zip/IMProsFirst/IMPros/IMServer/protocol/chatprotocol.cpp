#include "chatprotocol.h"

ChatProtocol::ChatProtocol()
{

}

ChatProtocol::~ChatProtocol()
{

}

void ChatProtocol::clearProtocolData()
{

}

void ChatProtocol::displayProtocol(void) const
{

}
const QByteArray ChatProtocol::packetProtocol() const
{

}
void ChatProtocol::unpacketProtocol(QDataStream &in)
{

}

