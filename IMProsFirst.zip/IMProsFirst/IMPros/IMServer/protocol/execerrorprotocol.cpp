#include "execerrorprotocol.h"

#include <QDebug>
#include "protocol.h"

ExecErrorProtocol::ExecErrorProtocol()
{
    Protocol::g_queueErrorProtocol.clear();
}

ExecErrorProtocol::~ExecErrorProtocol()
{

}

void ExecErrorProtocol::run()
{
    while(true)
    {
        if(!Protocol::g_queueErrorProtocol.isEmpty())
        {
            m_errorProtocol.clearProtocolData();
            m_errorProtocol = Protocol::g_queueErrorProtocol.dequeue();
            m_errorProtocol.displayProtocol();
            execErrorType();
        }

        msleep(20);
    }
}

void ExecErrorProtocol::execErrorType(void)
{
    qDebug() << "void ExecErrorProtocol::execErrorType(void)";
    switch (m_errorProtocol.m_errorType) {
    case ErrorType_None: execErrorTypeNone(); break;
    case ErrorType_Data: execErrorTypeData(); break;
    case ErrorType_Auth: execErrorTypeAuth(); break;
    case ErrorType_Serv: execErrorTypeServ(); break;
    default: break;
    }
}

void ExecErrorProtocol::execErrorTypeNone(void)
{
    qDebug() << "1111111111111111111";
    switch (m_errorProtocol.m_errorType) {
    case ErrorNone_CorrectBack: execErrorNoneCorrectBack(); break;
    case ErrorNone_HeartTest: execErrorNoneHeartTest(); break;
    case ErrorNone_HeartBack: execErrorNoneHeartBack(); break;
    default: break;
    }
}

void ExecErrorProtocol::execErrorTypeData(void)
{
    qDebug() << "2222222222222222222222222";
    switch (m_errorProtocol.m_errorType) {
    case ErrorData_LoginAsk: execErrorDataLoginAsk(); break;
    default: break;
    }
}

void ExecErrorProtocol::execErrorDataLoginAsk(void)
{
    qDebug() << "33333333333333333333333333";
}

void ExecErrorProtocol::execErrorTypeAuth(void)
{

}

void ExecErrorProtocol::execErrorTypeServ(void)
{

}

void ExecErrorProtocol::execErrorNoneCorrectBack(void)
{

}

void ExecErrorProtocol::execErrorNoneHeartTest(void)
{

}

void ExecErrorProtocol::execErrorNoneHeartBack(void)
{

}

