#ifndef EXECNORMALPROTOCOL_H
#define EXECNORMALPROTOCOL_H

#include <QThread>

#include "common.h"
#include "datapacket.h"
#include "normalprotocol.h"

class ExecNormalProtocol: public QThread
{
    Q_OBJECT

signals:
    void signalSendDataToClient(QByteArray buffer);
    void signalUserLoginSuccess(UserInfo info);

public:
    ExecNormalProtocol();
    ~ExecNormalProtocol();

    void execUserOperate(void);

    void execOperateCmdLogin(void);
    void execOperateCmdLoginAsk(void);
    void execOperateCmdExitAsk(void);
    void execOperateCmdRegisterAsk(void);

    void execOperateCmdUser(void);
    void execOperateCmdFriend(void);
    void execOperateCmdCrowd(void);
    void execOperateCmdChat(void);
    void execOperateCmdMood(void);

protected:
    void run();

private:
    NormalProtocol m_normalProtocol;
    DataPacket m_dataPacket;
};

#endif // EXECNORMALPROTOCOL_H
