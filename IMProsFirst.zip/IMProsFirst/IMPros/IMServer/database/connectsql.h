#ifndef CONNECTSQL_H
#define CONNECTSQL_H

#include <QSqlDatabase>


class DataBase
{
public:
    DataBase();
    ~DataBase();
};

#endif // CONNECTSQL_H
