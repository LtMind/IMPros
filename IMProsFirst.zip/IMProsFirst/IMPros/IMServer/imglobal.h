#ifndef IMGLOBAL_H
#define IMGLOBAL_H

#include <QMap>
#include <QTcpSocket>

typedef QMap<quint32, QTcpSocket*> MapUserAndSocket;

class IMGlobal
{
public:
    IMGlobal();
    ~IMGlobal();

    static quint32 g_msgID;
    static MapUserAndSocket g_mapUserAndSocket;
};

#endif // IMGLOBAL_H
