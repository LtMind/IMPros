#ifndef CONNECT_CLIENT_H
#define CONNECT_CLIENT_H

#include <QString>
#include <QList>
#include <QTcpSocket>
#include <QObject>

#include "datapacket.h"
#include "execnormalprotocol.h"

class ConnectClient: public QObject
{
    Q_OBJECT

signals:
    void signalUserLoginSuccess(UserInfo info);

public slots:
    void slotReadyRead();
    void slotSendDataToClient(QByteArray buffer);

public:
    ConnectClient(QTcpSocket *nect);
    ~ConnectClient();

private:
    QTcpSocket *m_socket;

    DataPacket m_recvDataPacket;
    ExecNormalProtocol *m_execNormalProtocol;
};

#endif // CONNECT_CLIENT_H
