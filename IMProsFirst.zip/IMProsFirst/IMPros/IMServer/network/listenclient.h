#ifndef LISENTCLIENT_H
#define LISENTCLIENT_H

#include <QObject>
#include <QTcpServer>
#include <QList>
#include <QTcpSocket>
#include "connectclient.h"


class ListenClient : public QObject
{
    Q_OBJECT

signals:
    void signalUserLoginSuccess(UserInfo info);

public slots:
    void slotServerConnected();

public:
    ListenClient();
    ~ListenClient();

private:
    QTcpServer *m_imServer;
};

#endif // LISENTCLIENT_H
