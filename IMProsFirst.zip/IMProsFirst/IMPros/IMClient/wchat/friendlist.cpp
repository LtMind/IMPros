#include "friendlist.h"
#include "ui_friendlist.h"
#include <QDebug>

FriendList::FriendList(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FriendList)
{
    ui->setupUi(this);

    m_info = new UserInfo;
}

FriendList::~FriendList()
{
    delete ui;
}

void FriendList::initUserInfo(UserInfo *info)
{
    m_info->updataUserinfo(info);
    ui->pb_name->setText(info->getName());
    info->printInfos();
    m_info->printInfos();
    delete info;
}


void FriendList::on_pb_name_clicked()
{
    emit signalClickUserInfo(m_info);
}

void FriendList::closeEvent(QCloseEvent *ev)
{
    qDebug() << "FriendList::closeEvent";
    emit signalCloseProject();
    ev->accept();
}
