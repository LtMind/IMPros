#ifndef PROTOCOL_H
#define PROTOCOL_H

#include "normalprotocol.h"
#include "errorprotocol.h"
#include "chatprotocol.h"

class Protocol
{
public:
    Protocol();

    static quint32 g_userMsgID;
    static quint32 g_localUser;

    static QueueNormalProtocol g_queueNormalProtocol;
    static QueueErrorProtocol g_queueErrorProtocol;
    static QueueChatProtocol g_queueChatProtocol;
    static QueueGroupChatProtocol g_queueGroupChatProtocol;
};

#endif // PROTOCOL_H
