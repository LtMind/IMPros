#include "protocol.h"

quint32 Protocol::g_userMsgID;
quint32 Protocol::g_localUser;

QueueNormalProtocol Protocol::g_queueNormalProtocol;
QueueErrorProtocol Protocol::g_queueErrorProtocol;
QueueChatProtocol Protocol::g_queueChatProtocol;
QueueGroupChatProtocol Protocol::g_queueGroupChatProtocol;

Protocol::Protocol()
{

}

