#include <QApplication>

#include "logiclayer.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    LogicLayer logic;
    logic.showLoginW();

    return app.exec();
}
